<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'Winner!@#0505');
define('DB_HOST', 'localhost');
define('DB_NAME', 'khurana');

define('USER_CREATE_FAILED', 0);
define('USER_CREATED_SUCCESSFULLY', 1);
define('USER_ALREADY_EXISTED', 2);
define('EMAIL_ALREADY_EXISTED', 3);
define('MOBILE_ALREADY_EXISTED', 4);
define('USER_NOT_ACTIVATED', 5);
?>
